import json
import os
import boto3

sns = boto3.client("sns")
SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]

def handler(event, context):
    print("Event:", json.dumps(event))

    if event["triggerSource"] != "PostConfirmation_ConfirmSignUp":
        return event

    user_attrs = event["request"]["userAttributes"]
    email = user_attrs.get("email")
    email_verified = user_attrs.get("email_verified")

    if not email or email_verified != "true":
        print("Email not verified or missing")
        return event

    sns.subscribe(
        TopicArn=SNS_TOPIC_ARN,
        Protocol="email",
        Endpoint=email,
        ReturnSubscriptionArn=False
    )

    print(f"Subscription initiated for {email}")
    return event
